import os, httpx

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()

async def transcribe_bytes(audio_bytes: bytes, filename: str = "voice.ogg") -> str:
    """Transcribe audio bytes using OpenAI Whisper (via API)."""
    if not OPENAI_API_KEY:
        return "(STT kapalı: OPENAI_API_KEY yok)"
    url = "https://api.openai.com/v1/audio/transcriptions"
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    files = {
        "file": (filename, audio_bytes, "application/octet-stream"),
        "model": (None, "whisper-1"),
        "response_format": (None, "text"),
        "language": (None, "tr")
    }
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.post(url, headers=headers, files=files)
        r.raise_for_status()
        return r.text.strip()