import os, asyncio
from typing import Optional

from fastapi import FastAPI, Request, HTTPException, Query
from pydantic import BaseModel
from dotenv import load_dotenv
import httpx

from .db import add_note, list_notes, init_db
from .stt import transcribe_bytes
from .tts import tts_to_mp3

load_dotenv()
init_db()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "").strip()
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").strip()
LOCAL_POLLING = os.getenv("LOCAL_POLLING", "0").strip() == "1"
OWNER_ID = int(os.getenv("OWNER_ID", "0"))

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is required")
if not WEBHOOK_SECRET:
    raise RuntimeError("WEBHOOK_SECRET is required")
if OWNER_ID <= 0:
    raise RuntimeError("OWNER_ID is required (numeric Telegram user id)")

TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}"
TELEGRAM_FILE_API = f"https://api.telegram.org/file/bot{BOT_TOKEN}"

app = FastAPI(title="Derya Mobile Bot V2")

class TgUser(BaseModel):
    id: int
    is_bot: Optional[bool] = False
    first_name: Optional[str] = None
    username: Optional[str] = None

class TgChat(BaseModel):
    id: int
    type: str

class TgVoice(BaseModel):
    file_id: str
    file_unique_id: Optional[str] = None
    duration: Optional[int] = None
    mime_type: Optional[str] = None

class TgAudio(BaseModel):
    file_id: str

class TgDocument(BaseModel):
    file_id: str
    mime_type: Optional[str] = None
    file_name: Optional[str] = None

class TgMessage(BaseModel):
    message_id: int
    from_: Optional[TgUser] = None
    chat: TgChat
    date: Optional[int] = None
    text: Optional[str] = None
    voice: Optional[TgVoice] = None
    audio: Optional[TgAudio] = None
    document: Optional[TgDocument] = None
    caption: Optional[str] = None
    class Config:
        fields = {"from_": "from"}

class Update(BaseModel):
    update_id: int
    message: Optional[TgMessage] = None

async def tg_send_text(chat_id: int, text: str) -> None:
    async with httpx.AsyncClient(timeout=30.0) as client:
        await client.post(f"{TELEGRAM_API}/sendMessage", data={"chat_id": chat_id, "text": text})

async def tg_send_voice(chat_id: int, mp3_bytes: bytes) -> None:
    async with httpx.AsyncClient(timeout=120.0) as client:
        files = {"voice": ("reply.mp3", mp3_bytes, "audio/mpeg")}
        await client.post(f"{TELEGRAM_API}/sendVoice", files=files, data={"chat_id": str(chat_id)})

async def get_file_bytes(file_id: str) -> bytes:
    async with httpx.AsyncClient(timeout=60.0) as client:
        r = await client.get(f"{TELEGRAM_API}/getFile", params={"file_id": file_id})
        r.raise_for_status()
        p = r.json()
        path = p.get("result", {}).get("file_path")
        if not path:
            return b""
        r2 = await client.get(f"{TELEGRAM_FILE_API}/{path}")
        r2.raise_for_status()
        return r2.content

def is_owner(user_id: Optional[int]) -> bool:
    return user_id == OWNER_ID

@app.get("/")
async def root():
    return {"ok": True, "service": "Derya Mobile Bot V2", "polling": LOCAL_POLLING}

@app.post("/webhook")
async def webhook(request: Request, secret: str = Query(default="")):
    if secret != WEBHOOK_SECRET:
        raise HTTPException(status_code=401, detail="Invalid secret")
    payload = await request.json()
    upd = Update.model_validate(payload)

    if not upd.message:
        return {"ok": True}

    chat_id = upd.message.chat.id
    user_id = upd.message.from_.id if upd.message.from_ else None

    if not is_owner(user_id):
        await tg_send_text(chat_id, "Üzgünüm, bu bot özel. Yetkin yok.")
        return {"ok": True}

    txt = (upd.message.text or "").strip()
    if txt.startswith("/"):
        cmd, *rest = txt.split(" ", 1)
        arg = rest[0].strip() if rest else ""
        if cmd == "/start":
            await tg_send_text(chat_id, "Derya Mobile V2 hazır 🧡 — sadece sana özel.")
        elif cmd == "/help":
            await tg_send_text(chat_id, "/start, /help, /post, /note <metin|list>, /voice <metin>")
        elif cmd == "/post":
            await tg_send_text(chat_id, "(/post) TRM tetikleyici hazır. Hangi modülü bağlayayım?")
        elif cmd == "/note":
            if arg.lower() == "list":
                rows = list_notes(20)
                if not rows:
                    await tg_send_text(chat_id, "Kayıtlı not yok.")
                else:
                    out = "\n".join([f"#{rid} — {t[:70]}..." for (rid, t, _dt) in rows])
                    await tg_send_text(chat_id, out)
            elif arg:
                add_note(arg)
                await tg_send_text(chat_id, "Not kaydedildi 📝")
            else:
                await tg_send_text(chat_id, "Kullanım: /note <metin> ya da /note list")
        elif cmd == "/voice":
            if not arg:
                await tg_send_text(chat_id, "Kullanım: /voice <metin> — Sesli yanıt üretirim.")
            else:
                mp3 = await tts_to_mp3(arg)
                if mp3:
                    await tg_send_voice(chat_id, mp3)
                else:
                    await tg_send_text(chat_id, "(TTS başarısız ya da kapalı)")
        else:
            await tg_send_text(chat_id, "Bilinmeyen komut. /help de")
        return {"ok": True}

    if upd.message.voice:
        b = await get_file_bytes(upd.message.voice.file_id)
        text = await transcribe_bytes(b, filename="voice.ogg")
        await tg_send_text(chat_id, f"STT: {text}")
        mp3 = await tts_to_mp3(f"Aldım: {text}")
        if mp3:
            await tg_send_voice(chat_id, mp3)
        return {"ok": True}

    if upd.message.text:
        await tg_send_text(chat_id, f"Echo: {upd.message.text}")
    return {"ok": True}