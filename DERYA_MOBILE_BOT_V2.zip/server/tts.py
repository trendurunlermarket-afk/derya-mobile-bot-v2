import os, httpx

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
VOICE = os.getenv("OPENAI_TTS_VOICE", "alloy")

async def tts_to_mp3(text: str) -> bytes:
    """Synthesize speech via OpenAI TTS to MP3."""
    if not OPENAI_API_KEY:
        return b""
    url = "https://api.openai.com/v1/audio/speech"
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "gpt-4o-mini-tts",
        "voice": VOICE,
        "input": text,
        "format": "mp3"
    }
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        return r.content