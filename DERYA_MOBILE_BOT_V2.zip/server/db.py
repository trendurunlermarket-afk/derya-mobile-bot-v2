import sqlite3, os

DB_PATH = os.getenv("DB_PATH", "derya_mobile.sqlite3")

def init_db():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, text TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    con.commit()
    return con

def add_note(text: str):
    con = init_db()
    cur = con.cursor()
    cur.execute("INSERT INTO notes(text) VALUES (?)", (text,))
    con.commit()
    con.close()

def list_notes(limit: int = 10):
    con = init_db()
    cur = con.cursor()
    cur.execute("SELECT id, text, created_at FROM notes ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    con.close()
    return rows