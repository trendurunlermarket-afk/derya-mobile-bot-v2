# Derya Mobile Bot — V2 (Telegram + FastAPI + Voice STT/TTS)

Telefonundan, PC’ye bağlı olmadan kullan: **Telegram** bot. Bu sürüm:
- **/start, /help, /post, /note, /voice** komutları
- **Sadece OWNER_ID** kullanabilsin (gizlilik)
- **Sesli mesaj → STT (Whisper via OpenAI)** ve **metin → TTS (OpenAI)** ile kadın sesi yanıt
- Basit **SQLite** not defteri (`/note your text`)
- Render / Railway uyumlu Docker
- .env ile gizli anahtarlar

> Not: OpenAI API kullanır. `OPENAI_API_KEY` gereklidir. Türkçe STT/TTS desteklenir.

---

## Hızlı Kurulum (Render)
1) Bu repo’yu GitHub’a yükle.
2) Render.com → New Web Service → **Docker**.
3) **Environment Variables** ekle:
   - `BOT_TOKEN` = BotFather token
   - `WEBHOOK_SECRET` = uzun rastgele dize
   - `PUBLIC_BASE_URL` = Render servis URL’in (deploydan sonra)
   - `OWNER_ID` = Telegram numeric user id’in
   - `OPENAI_API_KEY` = OpenAI anahtarın
   - `OPENAI_TTS_VOICE` = `alloy` (varsayılan) ya da beğendiğin başka bir ses
4) Deploy → sonra webhook’u ayarla:
```bash
curl -X POST "https://api.telegram.org/bot$BOT_TOKEN/setWebhook"   -d "url=$PUBLIC_BASE_URL/webhook?secret=$WEBHOOK_SECRET"
```
5) Telegram’da `/start` yaz, sonra metin veya ses dene: `/voice Merhaba Derya` ya da bir **sesli mesaj** gönder.

---

## Komutlar
- `/start` → Hoş geldin + yetki kontrolü
- `/help` → Komut özeti
- `/post` → (Kanca) TRM otomasyon tetikleyici (şimdilik stub, yakında bağlayacağız)
- `/note ...` → Metni SQLite’a kaydeder, `/note list` ile listeler
- `/voice ...` → Metni TTS yapar ve **kadın sesi** ses dosyası yollar.
  - Ayrıca **sesli mesaj** gönderirsen: indirir → STT → metni döner → istersek TTS yanıt üretir.

---

## Yerel Geliştirme (opsiyonel)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r server/requirements.txt
uvicorn server.main:app --host 0.0.0.0 --port 8000 --reload
```
Webhook yerine lokal test için: `LOCAL_POLLING=1` ortam değişkeni.

---

## Dosya Yapısı
```
server/
  main.py
  tts.py
  stt.py
  db.py
  requirements.txt
  Dockerfile
  .env.example
Procfile
README.md
```

---

## Notlar
- Ses kalitesi için `OPENAI_TTS_VOICE` ile farklı sesleri deneyebilirsin. Kadın‑naif tını için öneri: `verse`, `aria`, `alloy`. 
- TRM için `/post` içinde HTTP çağrısı veya Drive/Telegram tetikleyicisi bağlanacak alan işaretlendi.